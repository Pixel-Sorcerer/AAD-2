// Node class for BST
class Node {
    int key;
    int frequency; // To count how many times the key is inserted
    Node left, right;
    public Node(int key) {
        this.key = key;
        this.frequency = 1; // Initialize frequency to 1
        this.left = this.right = null;
    }
}
// SymbolTable class using BST
public class SymbolTable {
    private Node root;
    // Insert a key into the BST
    public void insert(int key) {
        root = insert(root, key);
    }
    private Node insert(Node node, int key) {
        if (node == null) {
            return new Node(key); // Create a new node if the tree is empty
        }
        if (key < node.key) {
            node.left = insert(node.left, key); // Insert in the left subtree
        } else if (key > node.key) {
            node.right = insert(node.right, key); // Insert in the right subtree
        } else {
            node.frequency++; // If key already exists, increase its frequency
        }
        return node;
    }
    // Search for a key in the BST
    public boolean search(int key) {
        return search(root, key);
    }
    private boolean search(Node node, int key) {
        if (node == null) {
            return false; // Key not found
        }
        if (key < node.key) {
            return search(node.left, key); // Search in the left subtree
        } else if (key > node.key) {
            return search(node.right, key); // Search in the right subtree
        } else {
            return true; // Key found
        }
    }
    // Get the frequency of a key
    public int frequency(int key) {
        return frequency(root, key);
    }
    private int frequency(Node node, int key) {
        if (node == null) {
            return 0; // Key not found, frequency is 0
        }
        if (key < node.key) {
            return frequency(node.left, key); // Search in the left subtree
        } else if (key > node.key) {
            return frequency(node.right, key); // Search in the right subtree
        } else {
            return node.frequency; // Return the frequency of the key
        }
    }
    // Main method to test the SymbolTable
    public static void main(String[] args) {
        SymbolTable st = new SymbolTable();
        st.insert(10);
        st.insert(5);
        st.insert(15);
        st.insert(5); // Inserting 5 again
        System.out.println("Search for 5: " + st.search(5)); // true
        System.out.println("Search for 20: " + st.search(20)); // false
        System.out.println("Frequency of 5: " + st.frequency(5)); // 2
        System.out.println("Frequency of 10: " + st.frequency(10)); // 1
    }
}