import java.util.Scanner;
public class Q1 {
    public static void main(String[] args) {
        Scanner ob = new Scanner(System.in);
        System.out.println("Enter your age:");
        int n = ob.nextInt();
        if (n<18){
            System.out.println("Not Eligible");
        }
        else{
            System.out.println("Eligible");
        }
    }
}
