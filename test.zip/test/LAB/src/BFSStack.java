import java.util.*;

public class BFSStack {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of vertices: ");
        int vertices = sc.nextInt();
        ArrayList<ArrayList<Integer>> adjList = new ArrayList<>();

        for (int i = 0; i < vertices; i++) {
            adjList.add(new ArrayList<>());
        }

        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();

        System.out.print("Is the graph directed? (yes/no): ");
        boolean isDirected = sc.next().equalsIgnoreCase("yes");

        System.out.println("Enter edges (source destination):");
        for (int i = 0; i < edges; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            adjList.get(u).add(v);
            if (!isDirected) {
                adjList.get(v).add(u); // Add reverse edge for undirected graph
            }
        }

        System.out.print("Enter starting vertex for DFS: ");
        int start = sc.nextInt();

        dfsUsingStack(adjList, start, vertices);
        sc.close();
    }

    public static void dfsUsingStack(ArrayList<ArrayList<Integer>> adjList, int start, int vertices) {
        boolean[] visited = new boolean[vertices];
        Stack<Integer> stack = new Stack<>();

        stack.push(start);

        System.out.println("DFS Traversal:");
        while (!stack.isEmpty()) {
            int node = stack.pop();

            if (!visited[node]) {
                System.out.print(node + " ");
                visited[node] = true;

                for (int neighbour : adjList.get(node)) {
                    if (!visited[neighbour]) {
                        stack.push(neighbour);
                    }
                }
            }
        }
        System.out.println();
    }
}