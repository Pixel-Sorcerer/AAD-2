import java.util.*;

public class DFSFindAllPaths {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of vertices: ");
        int vertices = sc.nextInt();
        ArrayList<ArrayList<Integer>> adjList = new ArrayList<>();

        for (int i = 0; i < vertices; i++) {
            adjList.add(new ArrayList<>());
        }

        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();

        System.out.print("Is the graph directed? (yes/no): ");
        boolean isDirected = sc.next().equalsIgnoreCase("yes");

        System.out.println("Enter edges (source destination):");
        for (int i = 0; i < edges; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            adjList.get(u).add(v);
            if (!isDirected) {
                adjList.get(v).add(u); // Add reverse edge for undirected graph
            }
        }

        System.out.print("Enter source vertex: ");
        int source = sc.nextInt();

        System.out.print("Enter destination vertex: ");
        int destination = sc.nextInt();

        ArrayList<Integer> path = new ArrayList<>();
        boolean[] visited = new boolean[vertices];

        System.out.println("All possible paths from " + source + " to " + destination + ":");
        findAllPathsDFS(adjList, source, destination, visited, path);

        sc.close();
    }

    public static void findAllPathsDFS(ArrayList<ArrayList<Integer>> adjList, int source, int destination, boolean[] visited, ArrayList<Integer> path) {
        visited[source] = true;
        path.add(source);

        if (source == destination) {
            System.out.println(path);
        } else {
            for (int neighbour : adjList.get(source)) {
                if (!visited[neighbour]) {
                    findAllPathsDFS(adjList, neighbour, destination, visited, path);
                }
            }
        }

        path.remove(path.size() - 1);
        visited[source] = false; // Backtrack
    }
}
