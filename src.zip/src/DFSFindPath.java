import java.util.*;

public class DFSFindPath {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Prompting user for the number of vertices
        System.out.print("Enter the number of vertices: ");
        int vertices = sc.nextInt();
        ArrayList<ArrayList<Integer>> adjList = new ArrayList<>();

        // Initializing the adjacency list for each vertex
        for (int i = 0; i < vertices; i++) {
            adjList.add(new ArrayList<>());
        }

        // Prompting user for the number of edges
        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();

        // Asking if the graph is directed
        System.out.print("Is the graph directed? (yes/no): ");
        boolean isDirected = sc.next().equalsIgnoreCase("yes");

        // Inputting edges into the graph
        System.out.println("Enter edges (source destination):");
        for (int i = 0; i < edges; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            adjList.get(u).add(v);
            if (!isDirected) {
                adjList.get(v).add(u);
            }
        }

        // Prompting user for source and destination vertices
        System.out.print("Enter the source vertex (u): ");
        int u = sc.nextInt();

        System.out.print("Enter the destination vertex (v): ");
        int v = sc.nextInt();

        // Checking if a path exists using DFS
        if (dfsFindPath(adjList, u, v, vertices)) {
            System.out.println("There is a path from " + u + " to " + v);
        } else {
            System.out.println("There is no path from " + u + " to " + v);
        }

        sc.close();
    }

    // DFS method to find a path from start to destination
    public static boolean dfsFindPath(ArrayList<ArrayList<Integer>> adjList, int start, int destination, int vertices) {
        boolean[] visited = new boolean[vertices]; // Array to track visited vertices
        Stack<Integer> stack = new Stack<>(); // Stack for DFS

        stack.push(start); // Start DFS from the source vertex

        while (!stack.isEmpty()) {
            int node = stack.pop(); // Get the top node from the stack

            if (node == destination) { // Check if the destination is reached
                return true;
            }

            if (!visited[node]) { // If the node has not been visited
                visited[node] = true; // Mark it as visited

                // Push all unvisited neighbors onto the stack
                for (int neighbour : adjList.get(node)) {
                    if (!visited[neighbour]) {
                        stack.push(neighbour);
                    }
                }
            }
        }
        return false; // Return false if no path is found
    }
}
