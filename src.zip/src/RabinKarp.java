import java.util.Scanner;

public class RabinKarp {
    static final int PRIME = 31; // A small prime number for simplicity

    public static int search(String text, String pattern) {
        int n = text.length(), m = pattern.length();
        int textHash = 0, patternHash = 0;
        int basePower = 1; // Instead of precomputing pow(PRIME, m-1), use this

        // Compute initial hash values for pattern and first substring of text
        for (int i = 0; i < m; i++) {
            patternHash = patternHash * PRIME + pattern.charAt(i);
            textHash = textHash * PRIME + text.charAt(i);
            if (i < m - 1){
                basePower *= PRIME; // Compute PRIME^(m-1) dynamically
            }
        }

        // Slide over text and compare hashes
        for (int i = 0; i <= n - m; i++) {
            if (patternHash == textHash) { // Possible match
                if (text.substring(i, i + m).equals(pattern)) {
                    return i; // Return match index
                }
            }

            // Compute next rolling hash
            if (i < n - m) {
                textHash = (textHash - text.charAt(i) * basePower) * PRIME + text.charAt(i + m);
            }
        }
        return -1; // No match found
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the text: ");
        String text = sc.nextLine();

        System.out.print("Enter the pattern to search: ");
        String pattern = sc.nextLine();

        int result = search(text, pattern);
        if (result != -1) {
            System.out.println("Pattern found at index: " + result);
        } else {
            System.out.println("Pattern not found in the text.");
        }

        sc.close();
    }
}
