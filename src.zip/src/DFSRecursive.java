import java.util.*;

public class DFSRecursive {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of vertices: ");
        int vertices = sc.nextInt();
        ArrayList<ArrayList<Integer>> adjList = new ArrayList<>();

        for (int i = 0; i < vertices; i++) {
            adjList.add(new ArrayList<>());
        }

        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();

        System.out.print("Is the graph directed? (yes/no): ");
        boolean isDirected = sc.next().equalsIgnoreCase("yes");

        System.out.println("Enter edges (source destination):");
        for (int i = 0; i < edges; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            adjList.get(u).add(v);
            if (!isDirected) {
                adjList.get(v).add(u); // Add reverse edge for undirected graph
            }
        }

        System.out.print("Enter starting vertex for DFS: ");
        int start = sc.nextInt();

        boolean[] visited = new boolean[vertices];
        System.out.println("DFS Traversal:");
        dfsRecursive(adjList, start, visited);
        System.out.println();

        sc.close();
    }

    public static void dfsRecursive(ArrayList<ArrayList<Integer>> adjList, int node, boolean[] visited) {
        if (visited[node]) return;

        System.out.print(node + " ");
        visited[node] = true;

        for (int neighbor : adjList.get(node)) {
            if (!visited[neighbor]) {
                dfsRecursive(adjList, neighbor, visited);
            }
        }
    }
}