import java.util.*;

class PrimsAlgorithm {
    public static void primMST(int[][] graph, int V) {
        boolean[] inMST = new boolean[V];
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        pq.add(new int[]{0, 0});
        int totalWeight = 0;

        System.out.println("Minimum Spanning Tree (MST) Edges:");

        while (!pq.isEmpty()) {
            int[] edge = pq.poll();
            int u = edge[0];
            if (inMST[u]) continue;

            inMST[u] = true;
            totalWeight += edge[1];
            System.out.println("Node " + u + " included in MST with edge weight " + edge[1]);

            for (int v = 0; v < V; v++) {
                if (graph[u][v] != 0 && !inMST[v]) {
                    pq.add(new int[]{v, graph[u][v]});
                }
            }
        }
        System.out.println("Total Weight of MST: " + totalWeight);
    }

    public class PrimsMST{
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter number of vertices: ");
            int V = sc.nextInt(), graph[][] = new int[V][V];
            System.out.println("Enter adjacency matrix:");
            for (int i = 0; i < V; i++)
                for (int j = 0; j < V; j++)
                    graph[i][j] = sc.nextInt();
            primMST(graph, V);
        }
    }
}
