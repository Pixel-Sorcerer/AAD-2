import java.util.*;

public class DFSPathCount {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of vertices: ");
        int vertices = sc.nextInt();
        ArrayList<ArrayList<Integer>> adjList = new ArrayList<>();

        for (int i = 0; i < vertices; i++) {
            adjList.add(new ArrayList<>());
        }

        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();

        System.out.print("Is the graph directed? (yes/no): ");
        boolean isDirected = sc.next().equalsIgnoreCase("yes");

        System.out.println("Enter edges (source destination):");
        for (int i = 0; i < edges; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            adjList.get(u).add(v);
            if (!isDirected) {
                adjList.get(v).add(u); // Add reverse edge for undirected graph
            }
        }

        System.out.print("Enter source vertex: ");
        int source = sc.nextInt();

        System.out.print("Enter destination vertex: ");
        int destination = sc.nextInt();

        boolean[] visited = new boolean[vertices];

        int count = countPathsDFS(adjList, source, destination, visited );
        System.out.println("Total paths from " + source + " to " + destination + ": " + count);

        sc.close();
    }

    public static int countPathsDFS(ArrayList<ArrayList<Integer>> adjList, int source, int destination, boolean[] visited) {
        if (source == destination) {
            return 1;
        }

        visited[source] = true;
        int pathCount = 0;

        for (int neighbour : adjList.get(source)) {
            if (!visited[neighbour]) {
                pathCount += countPathsDFS(adjList, neighbour, destination, visited);
            }
        }

        visited[source] = false; // Backtracking to explore other paths
        return pathCount;
    }
}
