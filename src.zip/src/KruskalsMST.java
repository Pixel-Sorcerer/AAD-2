import java.util.*;

class Edge implements Comparable<Edge> {
    int source, destination, weight;

    public int compareTo(Edge edge) {
        return this.weight - edge.weight;
    }
}

class Graph {
    int vertices, edges;
    Edge[] edgeList;

    Graph(int v, int e) {
        vertices = v;
        edges = e;
        edgeList = new Edge[e];
        for (int i = 0; i < e; i++) {
            edgeList[i] = new Edge();
        }
    }

    int find(int parent[], int i) {
        if (parent[i] == -1) {
            return i;
        }
        return find(parent, parent[i]);
    }

    void union(int parent[], int x, int y) {
        parent[x] = y;
    }

    void kruskalMST() {
        Edge result[] = new Edge[vertices];
        int e = 0;
        int i = 0;

        Arrays.sort(edgeList);
        int parent[] = new int[vertices];
        Arrays.fill(parent, -1);

        while (e < vertices - 1 && i < edgeList.length) {
            Edge nextEdge = edgeList[i++];
            int x = find(parent, nextEdge.source);
            int y = find(parent, nextEdge.destination);

            if (x != y) {
                result[e++] = nextEdge;
                union(parent, x, y);
            }
        }

        System.out.println("\nEdges in the Minimum Spanning Tree:");
        int totalWeight = 0;
        for (int j = 0; j < e; j++) {
            System.out.println(result[j].source + " -- " + result[j].destination + " == " + result[j].weight);
            totalWeight += result[j].weight;
        }
        System.out.println("Total weight of MST: " + totalWeight);
    }
}

public class KruskalsMST {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of vertices: ");
        int vertices = sc.nextInt();

        System.out.print("Enter number of edges: ");
        int edges = sc.nextInt();

        Graph graph = new Graph(vertices, edges);

        System.out.println("Enter edges in the format: source destination weight");
        for (int i = 0; i < edges; i++) {
            System.out.print("Edge " + (i + 1) + ": ");
            graph.edgeList[i].source = sc.nextInt();
            graph.edgeList[i].destination = sc.nextInt();
            graph.edgeList[i].weight = sc.nextInt();
        }

        graph.kruskalMST();
        sc.close();
    }
}
