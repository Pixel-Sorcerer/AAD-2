import java.util.HashMap;
import java.util.Scanner;

public class Hashing {
    public static void main(String[] args) {
        HashMap<String, String> phoneBook = new HashMap<>();
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of entries: ");
        int n = sc.nextInt();
        sc.nextLine(); // Consume leftover newline

        // Input key-value pairs
        for (int i = 0; i < n; i++) {
            System.out.print("Enter name: ");
            String name = sc.nextLine();
            System.out.print("Enter phone number: ");
            String phone = sc.nextLine();
            phoneBook.put(name, phone);
        }

        // Retrieve by key
        System.out.print("Enter name to search: ");
        String searchName = sc.nextLine();

        if (phoneBook.containsKey(searchName)) {
            System.out.println("Phone number: " + phoneBook.get(searchName));
        } else {
            System.out.println("Name not found in phone book.");
        }

        sc.close();
    }
}
