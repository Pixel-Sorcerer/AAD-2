import java.util.*;

public class BFSQueue {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of vertices: ");
        int vertices = sc.nextInt();
        ArrayList<ArrayList<Integer>> adjList = new ArrayList<>();

        for (int i = 0; i < vertices; i++) {
            adjList.add(new ArrayList<>());
        }

        System.out.print("Enter the number of edges: ");
        int edges = sc.nextInt();

        System.out.print("Is the graph directed? (yes/no): ");
        boolean isDirected = sc.next().equalsIgnoreCase("yes");

        System.out.println("Enter edges (source destination):");
        for (int i = 0; i < edges; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            adjList.get(u).add(v);
            if (!isDirected) {
                adjList.get(v).add(u);
            }
        }

        System.out.print("Enter starting vertex for BFS: ");
        int start = sc.nextInt();

        System.out.println("BFS Traversal:");
        bfs(adjList, start, vertices);

        sc.close();
    }

    public static void bfs(ArrayList<ArrayList<Integer>> adjList, int start, int vertices) {
        boolean[] visited = new boolean[vertices];
        Queue<Integer> queue = new LinkedList<>();

        queue.add(start);
        visited[start] = true;

        while (!queue.isEmpty()) {
            int node = queue.peek();  // Get front element without removing it
            queue.remove();           // Remove the front element

            System.out.print(node + " ");  // Print the current node

            for (int neighbor : adjList.get(node)) {
                if (!visited[neighbor]) {
                    queue.add(neighbor);
                    visited[neighbor] = true;
                }
            }
        }
        System.out.println(); // Ensure output formatting
    }
}
